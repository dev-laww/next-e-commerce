create view pg_stat_statements_info(dealloc, stats_reset) as
SELECT pg_stat_statements_info.dealloc,
       pg_stat_statements_info.stats_reset
FROM pg_stat_statements_info() pg_stat_statements_info(dealloc, stats_reset);

alter table pg_stat_statements_info
    owner to cloud_admin;

grant select on pg_stat_statements_info to public;

